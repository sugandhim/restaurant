
import static com.sun.java.accessibility.util.AWTEventMonitor.addActionListener;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GenerateBill extends JFrame{

   JTextField food,quantity;

   String[] columnNames = {"Food Name",
                        "Quantity",
                        "Price"
            };
   
   
  // JLabel totalP = new JLabel("TOTAL PRICE : 0.0tk");
   JLabel totalP = new JLabel();
   Object data[][] = new Object[100][3];
   int i = 0;
   double totalprice = 0;
    ArrayList<foodCart> foodList = new ArrayList<>();

   GenerateBill(){
       JPanel jp1 = new JPanel();
       this.setLayout(new GridLayout(2,2));
	   
       JLabel a = new JLabel("Food Name : ");
       jp1.add(a);
       food = new JTextField(30);
       jp1.add(food);
       JLabel b = new JLabel("Quantity : ");
       jp1.add(b);
       quantity = new JTextField(30);
       jp1.add(quantity);

       JButton ok = new JButton("OK");

       JPanel jp2 = new JPanel();
       jp2.setSize(400, 400);
       jp1.add(ok);
       ok.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            PreparedStatement pst;
            ResultSet rs;
            try{
    			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rest","root","root");

                pst = con.prepareStatement("select f_price from food where f_name = ?");
                pst.setString(1, food.getText());
                rs = pst.executeQuery();

                while (rs.next()){
                    foodCart f = new foodCart();
                    f.name = food.getText();
                    f.quantity = Integer.parseInt(quantity.getText());
                    f.totalPer = f.quantity*rs.getDouble("f_price");
                    totalprice += f.quantity*rs.getDouble("f_price");

                    food.setText("");
                    quantity.setText("");
                    
                    DefaultTableModel model =  new DefaultTableModel();
                    JTable table = new JTable( model );
                    model.setRowCount(0);
                    JOptionPane.showMessageDialog(null, "Total Price is Rs:" +totalprice);
                    setVisible(false);
                                       
                }
            }
            catch(Exception ex){
                System.out.println(ex);
            }
         }
      });
      

       this.add(jp1);
       this.add(jp2);
       this.setSize(400,300);
	    this.setLocationRelativeTo(null);
       this.setVisible(true);
   }


    class foodCart{
    String name;
    Double totalPer;
    int quantity;
}

}
