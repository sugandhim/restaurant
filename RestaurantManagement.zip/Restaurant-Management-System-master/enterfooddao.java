
public class enterfooddao {

}
