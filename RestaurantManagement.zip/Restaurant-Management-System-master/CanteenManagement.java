class CanteenManagement {

    public static void main(String[] args){


        
        Frame1 f=new Frame1();
       
    }



}
